/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author [Nombre del estudiante]
 * @version 1.0 - 16 nov. 2026 - Gestión de proyectos
 */

public class Proyecto implements Serializable {
    /*
     * Atributos
    */
    private String codigo;
    private String titulo;
    private LocalDate fechaInicio;
    private String unidadDuracion;//semanas, meses, años
    private byte duracionEstimada;
    private Cliente suCliente;
    private Empleado suGerente;
    private ArrayList<Empleado> suEquipo;
    private String estado;//Por defecto: INICIADO

    /*
     * Constructores
    */
        //Constructor con todos los parámetros (incluye el equipo)
    public Proyecto (String codigo, String titulo, LocalDate fechaInicio, String unidadDuracion, byte duracionEstimada,
                     Cliente suCliente, Empleado suGerente, ArrayList<Empleado> suEquipo) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.fechaInicio = fechaInicio;
        this.unidadDuracion = unidadDuracion;
        this.duracionEstimada = duracionEstimada;
        this.suCliente = suCliente;
        this.suGerente = suGerente;
        this.suEquipo = suEquipo;
        this.estado = "INICIADO";
    }

        //Constructor sin equipo: el equipo se crea vacío y se completa posteriormente
    public Proyecto (String codigo, String titulo, LocalDate fechaInicio, String unidadDuracion, byte duracionEstimada,
                     Cliente suCliente, Empleado suGerente) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.fechaInicio = fechaInicio;
        this.unidadDuracion = unidadDuracion;
        this.duracionEstimada = duracionEstimada;
        this.suCliente = suCliente;
        this.suGerente = suGerente;
        this.suEquipo = new ArrayList<>();
        this.estado = "INICIADO";
    }

    /*
     * Getter
    */
    public String getCodigo(){
        return codigo;
    }
    public String getTitulo(){
        return titulo;
    }
    public LocalDate getFechaInicio(){
        return fechaInicio;
    }
    public String getUnidadDuracion(){
        return unidadDuracion;
    }
    public byte getDuracionEstimada(){
        return duracionEstimada;
    }
    public Cliente getSuCliente(){
        return suCliente;
    }
    public Empleado getSuGerente(){
        return suGerente;
    }
    public ArrayList<Empleado> getSuEquipo(){
        return suEquipo;
    }
    public String getEstado(){
        return estado;
    }

    /*
     * Setter
    */
    public void setCodigo(String codigo){
        this.codigo = codigo;
    }
    public void setTitulo(String titulo){
        this.titulo = titulo;
    }
    public void setFechaInicio(LocalDate fechaInicio){
        this.fechaInicio = fechaInicio;
    }
    public void setUnidadDuracion(String unidadDuracion){
        this.unidadDuracion = unidadDuracion;
    }
    public void setDuracionEstimada(byte duracionEstimada){
        this.duracionEstimada = duracionEstimada;
    }
    public void setSuCliente(Cliente suCliente){
        this.suCliente = suCliente;
    }
    public void setSuGerente(Empleado suGerente){
        this.suGerente = suGerente;
    }
    public void setSuEquipo(ArrayList<Empleado> suEquipo){
        this.suEquipo = suEquipo;
    }
    public void setEstado(String estado){
        this.estado = estado;
    }

    /*
    * toString()
    */
    @Override
    public String toString() {
        return "Proyecto:"
                + "\n     Codigo: " + codigo
                + "\n     Titulo: " + titulo
                + "\n     Fecha de inicio: " + fechaInicio
                + "\n     Duracion estimada: " + duracionEstimada + " " + unidadDuracion
                + "\n     Estado: " + estado
                + "\n     Cliente: " + suCliente.getClass().getSimpleName() + ", " + suCliente.getNumeroIdentificacion() + " - " + suCliente.getNombre()
                + "\n     Gerente: " + suGerente.getNumeroIdentificacion() + " - " + suGerente.getNombreCompleto()
                + "\n     Integrantes del equipo: " + suEquipo.size();
    }

    /*
     * Métodos de negocio
    */

    /*
     * Método: determinarFechaFinalizacion
     *         La fecha de finalización es la fecha de inicio más la duración estimada,
     *         expresada en la unidad de duración (semanas, meses o años).
    */
    public LocalDate determinarFechaFinalizacion(){
        LocalDate fechaFinalizacion;
        if(unidadDuracion.equals("semanas")){
            fechaFinalizacion = fechaInicio.plusWeeks(duracionEstimada);
        } else if(unidadDuracion.equals("meses")){
            fechaFinalizacion = fechaInicio.plusMonths(duracionEstimada);
        } else{
            fechaFinalizacion = fechaInicio.plusYears(duracionEstimada);
        }
        return fechaFinalizacion;
    }

    /*
     * Método: agregarIntegrante
     *         Agrega un empleado al equipo del proyecto.
    */
    public void agregarIntegrante(Empleado nuevoIntegrante){
        suEquipo.add(nuevoIntegrante);
    }

    /*
     * Método: eliminarIntegrante
     *         Elimina del equipo al integrante cuyo número de identificación sea el indicado
     *         y lo devuelve. Si el integrante no pertenece al equipo devuelve null.
    */
    public Empleado eliminarIntegrante(String numeroIdentificacion){
        Empleado integranteEliminado = null;
        for(int i=0; i<suEquipo.size(); i++){
            if(suEquipo.get(i).getNumeroIdentificacion().equals(numeroIdentificacion)){
                integranteEliminado = suEquipo.remove(i);
                break;
            }
        }
        return integranteEliminado;
    }

}//fin class
