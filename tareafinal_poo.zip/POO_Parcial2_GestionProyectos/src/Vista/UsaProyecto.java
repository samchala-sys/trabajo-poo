/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Vista;

import Modelo.Cliente;
import Modelo.Contacto;
import Modelo.Empleado;
import Modelo.Empresa;
import Modelo.PersonaNatural;
import Modelo.Proyecto;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author [Nombre del estudiante]
 * @version 1.0 - 16 nov. 2026 - Gestión de proyectos
 */
public class UsaProyecto {
    /*
     * Definir y crear las colecciones "ArrayList"
    */
    static private ArrayList<Proyecto> losProyectos = new ArrayList<>();
    static private ArrayList<Cliente> losClientes = new ArrayList<>();

    /*
     * Método: solicitarDatoObligatorio
     *         Solicita un dato de tipo cadena y valida la restricción de obligatoriedad (dato no vacío).
     *         Devuelve el dato ingresado.
    */
    public static String solicitarDatoObligatorio(String mensaje, String titulo){
        String dato;
        do{
            dato = JOptionPane.showInputDialog(null, mensaje, titulo, JOptionPane.QUESTION_MESSAGE);
            if(dato.isEmpty() || dato.isBlank()){
                JOptionPane.showMessageDialog(null, "Entrada inválida: dato está vacío.\n", titulo, JOptionPane.ERROR_MESSAGE);
            }
        } while(dato.isEmpty() || dato.isBlank());
        return dato.trim();
    }

    /*
     * Método: solicitarEmpleado
     *         Solicita las características de un empleado (gerente o integrante del equipo), crea un objeto y lo devuelve.
     *         Si la operación falla por una excepción devuelve null.
    */
    public static Empleado solicitarEmpleado(String rol){
        //----- 1. Obtener los datos del objeto Empleado
        String numeroIdentificacion;
        String nombreCompleto;
        String tituloProfesional;
        byte aniosExperiencia;
        String titulo = "REGISTRAR EMPLEADO (" + rol + ")";

            //Validación por obligatoriedad
        numeroIdentificacion = solicitarDatoObligatorio("Número de identificación (" + rol + "), obligatorio", titulo + ": número identificación");
        nombreCompleto = solicitarDatoObligatorio("Nombre completo (" + rol + "), obligatorio", titulo + ": nombre completo");
        tituloProfesional = solicitarDatoObligatorio("Título profesional (" + rol + "), obligatorio", titulo + ": título profesional");

            //Gestión de excepción de formato numérico y Validación para restricción de dominio
        try{
            do{
                aniosExperiencia = Byte.parseByte(JOptionPane.showInputDialog(null, "Años de experiencia (" + rol + "), mayor o igual a 0",
                                                  titulo + ": años experiencia", JOptionPane.QUESTION_MESSAGE));
                if(aniosExperiencia<0){
                    JOptionPane.showMessageDialog(null, "Operación fallida: entrada inválida por valor incorrecto.\n",
                                                  titulo + ": años experiencia", JOptionPane.ERROR_MESSAGE);
                }
            } while(aniosExperiencia<0);
        } catch(NumberFormatException nfex){
            JOptionPane.showMessageDialog(null, "Operación fallida: entrada inválida por formato incorrecto.\n"
                                        + nfex.getMessage(), titulo + ": años experiencia", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        //----- 2. Crear y devolver el objeto Empleado
        Empleado objEmpleado;
        objEmpleado = new Empleado(numeroIdentificacion, nombreCompleto, tituloProfesional, aniosExperiencia);
        return objEmpleado;
    }

    /*
     * Método: solicitarCliente
     *         Solicita las características de un cliente (Empresa o PersonaNatural), crea un objeto y lo devuelve.
    */
    public static Cliente solicitarCliente(){
        //----- 1. Obtener los datos del objeto Cliente
        String tipoCliente;
        String numeroIdentificacion;
        String nombre;
        String nombreCiudad;
        String titulo = "REGISTRAR CLIENTE";

            //Validación por restricción de dominio
        do{
            tipoCliente = JOptionPane.showInputDialog(null, "Tipo de cliente\n1. Empresa\n2. Persona natural", titulo + ": tipo", JOptionPane.QUESTION_MESSAGE).trim();
            if(!tipoCliente.equals("1") && !tipoCliente.equals("2")){
                JOptionPane.showMessageDialog(null, "Entrada inválida: digite 1 (Empresa) o 2 (Persona natural).\n", titulo + ": tipo", JOptionPane.ERROR_MESSAGE);
            }
        } while(!tipoCliente.equals("1") && !tipoCliente.equals("2"));

            //Validación por obligatoriedad
        numeroIdentificacion = solicitarDatoObligatorio("Número de identificación del cliente, obligatorio", titulo + ": número identificación");
        nombre = solicitarDatoObligatorio("Nombre del cliente, obligatorio", titulo + ": nombre");
        nombreCiudad = solicitarDatoObligatorio("Ciudad del cliente, obligatorio", titulo + ": ciudad");

        //----- 2. Crear el objeto Cliente según el tipo
        Cliente objCliente;
        if(tipoCliente.equals("1")){
            String nombreContacto = solicitarDatoObligatorio("Nombre completo del contacto, obligatorio", titulo + ": contacto nombre");
            String cargoContacto = solicitarDatoObligatorio("Cargo del contacto, obligatorio", titulo + ": contacto cargo");
            String telefonoContacto = solicitarDatoObligatorio("Teléfono del contacto, obligatorio", titulo + ": contacto teléfono");
            String correoContacto = solicitarDatoObligatorio("Correo electrónico del contacto, obligatorio", titulo + ": contacto correo");
            Contacto objContacto = new Contacto(nombreContacto, cargoContacto, telefonoContacto, correoContacto);
            objCliente = new Empresa(numeroIdentificacion, nombre, nombreCiudad, objContacto);
        } else{
            String numeroTelefono = solicitarDatoObligatorio("Número de teléfono, obligatorio", titulo + ": teléfono");
            String correoElectronico = solicitarDatoObligatorio("Correo electrónico, obligatorio", titulo + ": correo");
            objCliente = new PersonaNatural(numeroIdentificacion, nombre, nombreCiudad, numeroTelefono, correoElectronico);
        }

        //----- 3. Devolver el objeto Cliente
        return objCliente;
    }

    /*
     * Método: registrarProyecto
     *         Solicita las características de un proyecto, crea un objeto, actualiza la colección y la devuelve.
    */
    public static ArrayList<Proyecto> registrarProyecto(ArrayList<Proyecto> datos){
        //----- 1. Obtener los datos del objeto Proyecto
        String codigo;
        String titulo;
        LocalDate fechaInicio;
        String unidadDuracion;
        byte duracionEstimada;
        boolean duracionValida;
        String rangoDuracion;
        Cliente suCliente;
        Empleado suGerente;

            //El código se genera automáticamente
        codigo = generarCodigoProyecto(datos);
        JOptionPane.showMessageDialog(null, "Código asignado al proyecto: " + codigo, "REGISTRAR PROYECTO: código", JOptionPane.INFORMATION_MESSAGE);

            //Validación por obligatoriedad y longitud
        do{
            titulo = JOptionPane.showInputDialog("Título del proyecto, obligatorio, entre 20 y 100 caracteres").trim();
            if(titulo.isEmpty() || titulo.isBlank() || titulo.length()<20 || titulo.length()>100){
                JOptionPane.showMessageDialog(null, "Entrada inválida: dato está vacío o no cumple la longitud exigida.\n",
                                            "REGISTRAR PROYECTO: título", JOptionPane.ERROR_MESSAGE);
            }
        } while(titulo.isEmpty() || titulo.isBlank() || titulo.length()<20 || titulo.length()>100);

            //Gestión de excepción de formato de fecha
        try{
            fechaInicio = LocalDate.parse(JOptionPane.showInputDialog("Fecha de inicio (aaaa-mm-dd), ej. 2026-02-15"));
        } catch(DateTimeException dtex){
            JOptionPane.showMessageDialog(null, "Operación fallida: entrada inválida por formato incorrecto.\n"
                                        + dtex.toString(), "REGISTRAR PROYECTO: fecha inicio", JOptionPane.ERROR_MESSAGE);
            return datos;
        }

            //Validación por restricción de dominio
        do{
            unidadDuracion = JOptionPane.showInputDialog("Unidad de duración: semanas, meses, años").trim().toLowerCase();
            if(!unidadDuracion.equals("semanas") && !unidadDuracion.equals("meses") && !unidadDuracion.equals("años")){
                JOptionPane.showMessageDialog(null, "Entrada inválida: dato no cumple con restricción.\n",
                                            "REGISTRAR PROYECTO: unidad duración", JOptionPane.ERROR_MESSAGE);
            }
        } while(!unidadDuracion.equals("semanas") && !unidadDuracion.equals("meses") && !unidadDuracion.equals("años"));

            //Gestión de excepción de formato numérico y Validación para restricción de dominio según la unidad
        if(unidadDuracion.equals("meses")){
            rangoDuracion = "entre 1 y 11, entre 13 y 23, o entre 25 y 35";
        } else{
            rangoDuracion = "entre 1 y 3";
        }
        try{
            do{
                duracionEstimada = Byte.parseByte(JOptionPane.showInputDialog("Duración estimada en " + unidadDuracion + ": " + rangoDuracion));
                if(unidadDuracion.equals("semanas")){
                    duracionValida = (duracionEstimada>=1 && duracionEstimada<=3);
                } else if(unidadDuracion.equals("meses")){
                    duracionValida = (duracionEstimada>=1 && duracionEstimada<=11) || (duracionEstimada>=13 && duracionEstimada<=23)
                                     || (duracionEstimada>=25 && duracionEstimada<=35);
                } else{
                    duracionValida = (duracionEstimada>=1 && duracionEstimada<=3);
                }
                if(!duracionValida){
                    JOptionPane.showMessageDialog(null, "Operación fallida: entrada inválida por valor incorrecto.\n",
                                                "REGISTRAR PROYECTO: duración estimada", JOptionPane.ERROR_MESSAGE);
                }
            } while(!duracionValida);
        } catch(NumberFormatException nfex){
            JOptionPane.showMessageDialog(null, "Operación fallida: entrada inválida por formato incorrecto.\n"
                                        + nfex.getMessage(), "REGISTRAR PROYECTO: duración estimada", JOptionPane.ERROR_MESSAGE);
            return datos;
        }

            //Datos del cliente
        suCliente = solicitarCliente();

            //Datos del gerente (si la operación falla por una excepción no se registra el proyecto)
        suGerente = solicitarEmpleado("gerente del proyecto");
        if(suGerente == null){
            return datos;
        }

        //----- 2. Crear el objeto Proyecto (sin equipo: se registra posteriormente)

        Proyecto objProyecto;
        objProyecto = new Proyecto(codigo, titulo, fechaInicio, unidadDuracion, duracionEstimada, suCliente, suGerente);

        //----- 3. Almacenar el objeto Proyecto en la colección de proyectos

        datos.add(objProyecto);

        //------ 4. Devolver la colección de proyectos
        return datos;
    }

    /*
     * Método: generarCodigoProyecto
     *         Genera el código de un proyecto: año actual, un guión y un consecutivo de 3 dígitos
     *         que inicia en 1 cada año. Ej. 2026-001, 2026-002.
    */
    public static String generarCodigoProyecto(ArrayList<Proyecto> datos){
        String codigo;
        int anio = LocalDate.now().getYear();
        int consecutivo = 1;

        //Contar los proyectos ya registrados en el año actual
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getCodigo().startsWith(anio + "-")){
                consecutivo++;
            }
        }
        codigo = anio + "-" + String.format("%03d", consecutivo);
        return codigo;
    }

    /*
    * Método: consultarTodosProyectos
    *         Conforma una cadena con toda la información (atributos y fecha de finalización) de cada uno de los proyectos
    *         contenidos en la colección respectiva.
    */
    public static String consultarTodosProyectos(ArrayList<Proyecto> datos){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar todos los proyectos\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        for(int i=0; i<datos.size(); i++){
            resultado += datos.get(i).toString();
            resultado += "\n     Fecha de finalizacion: " + datos.get(i).determinarFechaFinalizacion();
            resultado += "\n";
        }
        return resultado;
    }

    /*
    * Método: consultarProyectosEnCurso
    *         Conforma una cadena con toda la información (atributos y fecha de finalización) de cada uno de los proyectos
    *         contenidos en la colección respectiva que se encuentren con estado "EN CURSO".
    */
    public static String consultarProyectosEnCurso(ArrayList<Proyecto> datos){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar los proyectos en curso\n";
        boolean encontrado = false;

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getEstado().equals("EN CURSO")){
                resultado += datos.get(i).toString();
                resultado += "\n     Fecha de finalizacion: " + datos.get(i).determinarFechaFinalizacion();
                resultado += "\n";
                encontrado = true;
            }
        }
        if(!encontrado){
            resultado += "No hay proyectos en curso.";
        }
        return resultado;
    }

    /*
    * Método: consultarPrimerProyecto
    *         Conforma una cadena con toda la información (atributos y fecha de finalización) del primer proyecto registrado.
    */
    public static String consultarPrimerProyecto(ArrayList<Proyecto> datos){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar el primer proyecto registrado\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        resultado += datos.get(0).toString();
        resultado += "\n     Fecha de finalizacion: " + datos.get(0).determinarFechaFinalizacion();
        resultado += "\n";
        return resultado;
    }

    /*
    * Método: consultarUltimoProyecto
    *         Conforma una cadena con toda la información (atributos y fecha de finalización) del último proyecto registrado.
    */
    public static String consultarUltimoProyecto(ArrayList<Proyecto> datos){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar el último proyecto registrado\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        resultado += datos.get(datos.size()-1).toString();
        resultado += "\n     Fecha de finalizacion: " + datos.get(datos.size()-1).determinarFechaFinalizacion();
        resultado += "\n";
        return resultado;
    }

    /*
    * Método: consultarProyectoDadoCodigo
    *         Conforma una cadena con toda la información (atributos y fecha de finalización) del proyecto
    *         contenido en la colección respectiva que cumpla el valor indicado por el parámetro codigoProyecto.
    */
    public static String consultarProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar proyecto dado código\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getCodigo().equals(codigoProyecto)){
                resultado += datos.get(i).toString();
                resultado += "\n     Fecha de finalizacion: " + datos.get(i).determinarFechaFinalizacion();
                resultado += "\n";
                return resultado;
            }
        }
        resultado += "No existe un proyecto con el código " + codigoProyecto + ".";
        return resultado;
    }

    /*
    * Método: consultarGerenteProyectoDadoCodigo
    *         Conforma una cadena con el título y la información del gerente del proyecto
    *         contenido en la colección respectiva que cumpla el valor indicado por el parámetro codigoProyecto.
    */
    public static String consultarGerenteProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar gerente de un proyecto dado código\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getCodigo().equals(codigoProyecto)){
                resultado += "Proyecto: " + datos.get(i).getTitulo();
                resultado += "\nGerente del proyecto\n" + datos.get(i).getSuGerente().toString();
                resultado += "\n";
                return resultado;
            }
        }
        resultado += "No existe un proyecto con el código " + codigoProyecto + ".";
        return resultado;
    }

    /*
    * Método: consultarEquipoProyectoDadoCodigo
    *         Conforma una cadena con el título y la información de cada uno de los integrantes del equipo del proyecto
    *         contenido en la colección respectiva que cumpla el valor indicado por el parámetro codigoProyecto.
    */
    public static String consultarEquipoProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar equipo de un proyecto dado código\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getCodigo().equals(codigoProyecto)){
                resultado += "Proyecto: " + datos.get(i).getTitulo() + "\n";
                if(datos.get(i).getSuEquipo().isEmpty()){
                    resultado += "El proyecto aún no tiene equipo registrado.";
                    return resultado;
                }
                for(int j=0; j<datos.get(i).getSuEquipo().size(); j++){
                    resultado += datos.get(i).getSuEquipo().get(j).toString();
                    resultado += "\n";
                }
                return resultado;
            }
        }
        resultado += "No existe un proyecto con el código " + codigoProyecto + ".";
        return resultado;
    }

    /*
    * Método: consultarProyectosDadoNumIDEGerente
    *         Conforma una cadena con toda la información (atributos y fecha de finalización) de cada uno de los proyectos
    *         contenidos en la colección respectiva cuyo gerente esté identificado con el valor del parámetro numIDEGerente.
    */
    public static String consultarProyectosDadoNumIDEGerente(ArrayList<Proyecto> datos, String numIDEGerente){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar proyectos dado número id del gerente\n";
        boolean encontrado = false;

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getSuGerente().getNumeroIdentificacion().equals(numIDEGerente)){
                resultado += datos.get(i).toString();
                resultado += "\n     Fecha de finalizacion: " + datos.get(i).determinarFechaFinalizacion();
                resultado += "\n";
                encontrado = true;
            }
        }
        if(!encontrado){
            resultado += "No hay proyectos con el gerente identificado con " + numIDEGerente + ".";
        }
        return resultado;
    }

    /*
    * Método: consultarProyectosDadoNumIDECliente
    *         Conforma una cadena con toda la información (atributos y fecha de finalización) de cada uno de los proyectos
    *         contenidos en la colección respectiva cuyo cliente esté identificado con el valor del parámetro numIDECliente.
    */
    public static String consultarProyectosDadoNumIDECliente(ArrayList<Proyecto> datos, String numIDECliente){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar proyectos dado número id del cliente\n";
        boolean encontrado = false;

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getSuCliente().getNumeroIdentificacion().equals(numIDECliente)){
                resultado += datos.get(i).toString();
                resultado += "\n     Fecha de finalizacion: " + datos.get(i).determinarFechaFinalizacion();
                resultado += "\n";
                encontrado = true;
            }
        }
        if(!encontrado){
            resultado += "No hay proyectos con el cliente identificado con " + numIDECliente + ".";
        }
        return resultado;
    }

    /*
    * Método: consultarProyectosDadoTipoCliente
    *         Conforma una cadena con toda la información (atributos y fecha de finalización) de cada uno de los proyectos
    *         contenidos en la colección respectiva cuyo tipo de cliente (Empresa, PersonaNatural) sea igual al parámetro tipoCliente.
    */
    public static String consultarProyectosDadoTipoCliente(ArrayList<Proyecto> datos, String tipoCliente){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Consultar proyectos dado tipo de cliente\n";
        boolean encontrado = false;

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: agregar la información solicitada al resultado y devolverlo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getSuCliente().getClass().getSimpleName().equalsIgnoreCase(tipoCliente)){
                resultado += datos.get(i).toString();
                resultado += "\n     Fecha de finalizacion: " + datos.get(i).determinarFechaFinalizacion();
                resultado += "\n";
                encontrado = true;
            }
        }
        if(!encontrado){
            resultado += "No hay proyectos con clientes de tipo " + tipoCliente + ".";
        }
        return resultado;
    }

    /*
     * Método: registrarIntegranteProyectoDadoCodigo
     *         Realiza el registro de un integrante del equipo del proyecto indicado por el parámetro codigoProyecto.
    */
    public static String registrarIntegranteProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Registrar integrante a un proyecto dado código\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: solicitar los datos del integrante y crear el empleado
        Empleado integrante = solicitarEmpleado("integrante del equipo");
        if(integrante == null){
            resultado += "Operación fallida: el integrante no fue registrado.";
            return resultado;
        }

        //2c. Buscar el proyecto y agregar el integrante a su equipo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getCodigo().equals(codigoProyecto)){
                datos.get(i).agregarIntegrante(integrante);
                resultado += "Integrante registrado en el proyecto " + datos.get(i).getTitulo() + ".";
                return resultado;
            }
        }
        resultado += "No existe un proyecto con el código " + codigoProyecto + ".";
        return resultado;
    }

    /*
     * Método: registrarEquipoProyectoDadoCodigo
     *         Realiza el registro de todos los integrantes del equipo del proyecto indicado por el parámetro codigoProyecto.
    */
    public static String registrarEquipoProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Registrar equipo a un proyecto dado código\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: buscar el proyecto
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getCodigo().equals(codigoProyecto)){

                //Gestión de excepción de formato numérico y Validación para restricción de dominio
                int cantidad;
                try{
                    do{
                        cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de integrantes a registrar, mayor que 0"));
                        if(cantidad<=0){
                            JOptionPane.showMessageDialog(null, "Operación fallida: entrada inválida por valor incorrecto.\n",
                                                        "REGISTRAR EQUIPO: cantidad", JOptionPane.ERROR_MESSAGE);
                        }
                    } while(cantidad<=0);
                } catch(NumberFormatException nfex){
                    JOptionPane.showMessageDialog(null, "Operación fallida: entrada inválida por formato incorrecto.\n"
                                                + nfex.getMessage(), "REGISTRAR EQUIPO: cantidad", JOptionPane.ERROR_MESSAGE);
                    resultado += "Operación fallida: el equipo no fue registrado.";
                    return resultado;
                }

                //Ciclo para llenar la lista de integrantes (equipo)
                ArrayList<Empleado> equipo = new ArrayList<>();
                for(int j=1; j<=cantidad; j++){
                    Empleado integrante = solicitarEmpleado("integrante " + j + " de " + cantidad);
                    if(integrante == null){
                        resultado += "Operación fallida: el equipo no fue registrado.";
                        return resultado;
                    }
                    equipo.add(integrante);
                }

                //Actualizar el equipo del proyecto indicado
                datos.get(i).setSuEquipo(equipo);
                resultado += "Equipo del proyecto " + datos.get(i).getTitulo() + " actualizado: " + cantidad + " integrante(s).";
                return resultado;
            }
        }
        resultado += "No existe un proyecto con el código " + codigoProyecto + ".";
        return resultado;
    }

    /*
     * Método: actualizarEstadoProyectoDadoCodigo
     *         Actualiza el estado del proyecto indicado por el parámetro codigoProyecto.
     *         Estados: INICIADO, EN CURSO, CANCELADO, FINALIZADO, SUSPENDIDO, APLAZADO.
    */
    public static String actualizarEstadoProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Actualizar estado de un proyecto dado código\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: buscar el proyecto
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getCodigo().equals(codigoProyecto)){

                //Validación por restricción de dominio
                String nuevoEstado;
                do{
                    nuevoEstado = JOptionPane.showInputDialog("Estado actual: " + datos.get(i).getEstado()
                                + "\nNuevo estado: INICIADO, EN CURSO, CANCELADO, FINALIZADO, SUSPENDIDO, APLAZADO").trim().toUpperCase();
                    if(!nuevoEstado.equals("INICIADO") && !nuevoEstado.equals("EN CURSO") && !nuevoEstado.equals("CANCELADO")
                       && !nuevoEstado.equals("FINALIZADO") && !nuevoEstado.equals("SUSPENDIDO") && !nuevoEstado.equals("APLAZADO")){
                        JOptionPane.showMessageDialog(null, "Entrada inválida: dato no cumple con restricción.\n",
                                                    "ACTUALIZAR ESTADO: nuevo estado", JOptionPane.ERROR_MESSAGE);
                    }
                } while(!nuevoEstado.equals("INICIADO") && !nuevoEstado.equals("EN CURSO") && !nuevoEstado.equals("CANCELADO")
                        && !nuevoEstado.equals("FINALIZADO") && !nuevoEstado.equals("SUSPENDIDO") && !nuevoEstado.equals("APLAZADO"));

                datos.get(i).setEstado(nuevoEstado);
                resultado += "Estado del proyecto " + datos.get(i).getTitulo() + " actualizado a " + nuevoEstado + ".";
                return resultado;
            }
        }
        resultado += "No existe un proyecto con el código " + codigoProyecto + ".";
        return resultado;
    }

    /*
     * Método: eliminarIntegranteProyectoDadoCodigo
     *         Realiza la eliminación de un integrante del equipo del proyecto indicado por el parámetro codigoProyecto.
    */
    public static String eliminarIntegranteProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto){
        //----- 1. Definir e inicializar la cadena a devolver
        String resultado = "Eliminar integrante de un proyecto dado código\n";

        //----- 2. Manejo de la validación por restricción de lista vacía

        //2a. Si la lista está vacía: agregar mensaje indicando la situación al resultado y devolverlo
        if(datos.isEmpty()){
            resultado += "No hay proyectos registrados.";
            return resultado;
        }

        //2b. Si la lista está llena: solicitar el número de identificación del integrante
        String numeroIdeIntegrante;
        numeroIdeIntegrante = solicitarDatoObligatorio("Número de identificación del integrante a eliminar, obligatorio", "ELIMINAR INTEGRANTE: número identificación");

        //2c. Buscar el proyecto y eliminar el integrante de su equipo
        for(int i=0; i<datos.size(); i++){
            if(datos.get(i).getCodigo().equals(codigoProyecto)){
                Empleado integranteEliminado = datos.get(i).eliminarIntegrante(numeroIdeIntegrante);
                if(integranteEliminado != null){
                    resultado += "Integrante eliminado del proyecto " + datos.get(i).getTitulo() + ":\n" + integranteEliminado.toString();
                } else{
                    resultado += "El integrante identificado con " + numeroIdeIntegrante + " no pertenece al equipo del proyecto.";
                }
                return resultado;
            }
        }
        resultado += "No existe un proyecto con el código " + codigoProyecto + ".";
        return resultado;
    }

    /*
     * Método: generarArchivoDeObjetosProyectos
     *         Crea el archivo "datosProyectos" y guarda en él cada uno de los proyectos de la colección.
    */
    public static void generarArchivoDeObjetosProyectos(ArrayList<Proyecto> datos){
        //----- 1. Manejo de la validación por restricción de lista vacía
        if(datos.isEmpty()){
            JOptionPane.showMessageDialog(null, "No hay proyectos registrados.", "GENERAR ARCHIVO DE PROYECTOS", JOptionPane.WARNING_MESSAGE);
            return;
        }

        //----- 2. Crear y abrir el archivo, guardar cada proyecto y cerrar el archivo (se cierra automáticamente al terminar el try)
        try(ObjectOutputStream archivo = new ObjectOutputStream(new FileOutputStream("datosProyectos"))){
            for(int i=0; i<datos.size(); i++){
                archivo.writeObject(datos.get(i));
            }
            JOptionPane.showMessageDialog(null, "Archivo \"datosProyectos\" generado con " + datos.size() + " proyecto(s).",
                                        "GENERAR ARCHIVO DE PROYECTOS", JOptionPane.INFORMATION_MESSAGE);
        } catch(IOException ioex){
            JOptionPane.showMessageDialog(null, "Operación fallida: no fue posible generar el archivo.\n"
                                        + ioex.getMessage(), "GENERAR ARCHIVO DE PROYECTOS", JOptionPane.ERROR_MESSAGE);
        }
    }

    /*
     * Método: leerArchivoDeObjetosProyectos
     *         Abre el archivo existente "datosProyectos", guarda cada registro en una colección y la devuelve.
    */
    public static ArrayList<Proyecto> leerArchivoDeObjetosProyectos(){
        //----- 1. Crear la colección "datos" de objetos Proyecto
        ArrayList<Proyecto> datos = new ArrayList<>();

        //----- 2. Abrir el archivo, recorrerlo guardando cada registro en "datos" y cerrar el archivo
        try(ObjectInputStream archivo = new ObjectInputStream(new FileInputStream("datosProyectos"))){
            while(true){
                datos.add((Proyecto) archivo.readObject());
            }
        } catch(EOFException eofex){
            //Fin del archivo: se leyeron todos los registros
        } catch(FileNotFoundException fnfex){
            JOptionPane.showMessageDialog(null, "Operación fallida: el archivo \"datosProyectos\" no existe.\n"
                                        + "Genérelo primero con la opción 13.", "LEER ARCHIVO DE PROYECTOS", JOptionPane.ERROR_MESSAGE);
        } catch(IOException | ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Operación fallida: no fue posible leer el archivo.\n"
                                        + ex.getMessage(), "LEER ARCHIVO DE PROYECTOS", JOptionPane.ERROR_MESSAGE);
        }

        //----- 3. Devolver la colección de proyectos
        return datos;
    }

    /*
     * Método: generarArchivoDeObjetosClientes
     *         Crea el archivo "datosClientes" y guarda en él el cliente de cada uno de los proyectos de la colección.
    */
    public static void generarArchivoDeObjetosClientes(ArrayList<Proyecto> datos){
        //----- 1. Manejo de la validación por restricción de lista vacía
        if(datos.isEmpty()){
            JOptionPane.showMessageDialog(null, "No hay proyectos registrados.", "GENERAR ARCHIVO DE CLIENTES", JOptionPane.WARNING_MESSAGE);
            return;
        }

        //----- 2. Crear y abrir el archivo, guardar el cliente de cada proyecto y cerrar el archivo (se cierra automáticamente al terminar el try)
        try(ObjectOutputStream archivo = new ObjectOutputStream(new FileOutputStream("datosClientes"))){
            for(int i=0; i<datos.size(); i++){
                archivo.writeObject(datos.get(i).getSuCliente());
            }
            JOptionPane.showMessageDialog(null, "Archivo \"datosClientes\" generado con " + datos.size() + " registro(s).",
                                        "GENERAR ARCHIVO DE CLIENTES", JOptionPane.INFORMATION_MESSAGE);
        } catch(IOException ioex){
            JOptionPane.showMessageDialog(null, "Operación fallida: no fue posible generar el archivo.\n"
                                        + ioex.getMessage(), "GENERAR ARCHIVO DE CLIENTES", JOptionPane.ERROR_MESSAGE);
        }
    }

    /*
     * Método: leerArchivoDeObjetosClientes
     *         Abre el archivo existente "datosClientes", guarda cada registro en una colección verificando
     *         que no se repita (mismo número de identificación) y la devuelve.
    */
    public static ArrayList<Cliente> leerArchivoDeObjetosClientes(){
        //----- 1. Crear la colección "datos" de objetos Cliente
        ArrayList<Cliente> datos = new ArrayList<>();

        //----- 2. Abrir el archivo, recorrerlo guardando cada registro en "datos" y cerrar el archivo
        try(ObjectInputStream archivo = new ObjectInputStream(new FileInputStream("datosClientes"))){
            while(true){
                Cliente objCliente = (Cliente) archivo.readObject();

                //Validar que el cliente no esté repetido
                boolean repetido = false;
                for(int i=0; i<datos.size(); i++){
                    if(datos.get(i).getNumeroIdentificacion().equals(objCliente.getNumeroIdentificacion())){
                        repetido = true;
                        break;
                    }
                }
                if(!repetido){
                    datos.add(objCliente);
                }
            }
        } catch(EOFException eofex){
            //Fin del archivo: se leyeron todos los registros
        } catch(FileNotFoundException fnfex){
            JOptionPane.showMessageDialog(null, "Operación fallida: el archivo \"datosClientes\" no existe.\n"
                                        + "Genérelo primero con la opción 14.", "LEER ARCHIVO DE CLIENTES", JOptionPane.ERROR_MESSAGE);
        } catch(IOException | ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Operación fallida: no fue posible leer el archivo.\n"
                                        + ex.getMessage(), "LEER ARCHIVO DE CLIENTES", JOptionPane.ERROR_MESSAGE);
        }

        //----- 3. Devolver la colección de clientes
        return datos;
    }

    /*
     * Método: gestionarMenuOperaciones
     *         Ejecutar las operaciones y funcionalidades del aplicativo.
    */
    public static void gestionarMenuOperaciones(){
        int opcion;
        String codigoProyecto;
        String numeroIde;
        String tipoCliente;
        String resultado;
        ArrayList<Proyecto> proyectosLeidos;
        ArrayList<Cliente> clientesLeidos;

        do{
            //Gestión de excepción de formato numérico
            try{
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                                        "1. Registrar un proyecto\n"
                                        + "2. Consultar todos los proyectos\n"
                                        + "3. Consultar los proyectos en curso\n"
                                        + "4. Consultar el primer proyecto registrado\n"
                                        + "5. Consultar el último proyecto registrado\n"
                                        + "6. Consultar el gerente de un proyecto\n"
                                        + "7. Consultar el equipo de un proyecto\n"
                                        + "8. Consultar los proyectos de un gerente\n"
                                        + "9. Consultar los proyectos de un cliente\n"
                                        + "10. Registrar un integrante a un proyecto\n"
                                        + "11. Registrar el equipo a un proyecto\n"
                                        + "12. Eliminar un integrante de un proyecto\n"
                                        + "13. Generar un archivo de objetos de todos los proyectos\n"
                                        + "14. Generar un archivo de objetos de todos los clientes\n"
                                        + "15. Leer un archivo de objetos de todos los proyectos\n"
                                        + "16. Leer un archivo de objetos de todos los clientes\n"
                                        + "17. Consultar un proyecto dado su código\n"
                                        + "18. Consultar los proyectos dado el tipo de cliente\n"
                                        + "19. Actualizar el estado de un proyecto\n"
                                        + "0. Salir\n"
                                        + "\nSeleccione la opción deseada\n",
                                        "GESTIÓN DE PROYECTOS", JOptionPane.QUESTION_MESSAGE));
            } catch(NumberFormatException nfex){
                JOptionPane.showMessageDialog(null, "Operación fallida: entrada inválida por formato incorrecto.\n"
                                            + nfex.getMessage(), "GESTIÓN DE PROYECTOS: menú", JOptionPane.ERROR_MESSAGE);
                opcion = -1;
            }

            switch(opcion){
                case 1:
                    JOptionPane.showMessageDialog(null, "Operación iniciada", "REGISTRO DE PROYECTO", JOptionPane.INFORMATION_MESSAGE);
                    losProyectos = registrarProyecto(losProyectos);
                    JOptionPane.showMessageDialog(null, "Operación finalizada", "REGISTRO DE PROYECTO", JOptionPane.INFORMATION_MESSAGE);
                    break;

                case 2:
                    JOptionPane.showMessageDialog(null, consultarTodosProyectos(losProyectos));
                    break;

                case 3:
                    JOptionPane.showMessageDialog(null, consultarProyectosEnCurso(losProyectos));
                    break;

                case 4:
                    JOptionPane.showMessageDialog(null, consultarPrimerProyecto(losProyectos));
                    break;

                case 5:
                    JOptionPane.showMessageDialog(null, consultarUltimoProyecto(losProyectos));
                    break;

                case 6:
                    codigoProyecto = solicitarDatoObligatorio("Código del proyecto a consultar, obligatorio", "CONSULTAR GERENTE DE UN PROYECTO");
                    JOptionPane.showMessageDialog(null, consultarGerenteProyectoDadoCodigo(losProyectos, codigoProyecto));
                    break;

                case 7:
                    codigoProyecto = solicitarDatoObligatorio("Código del proyecto a consultar, obligatorio", "CONSULTAR EQUIPO DE UN PROYECTO");
                    JOptionPane.showMessageDialog(null, consultarEquipoProyectoDadoCodigo(losProyectos, codigoProyecto));
                    break;

                case 8:
                    numeroIde = solicitarDatoObligatorio("Número de identificación del gerente a consultar, obligatorio", "CONSULTAR PROYECTOS DE UN GERENTE");
                    JOptionPane.showMessageDialog(null, consultarProyectosDadoNumIDEGerente(losProyectos, numeroIde));
                    break;

                case 9:
                    numeroIde = solicitarDatoObligatorio("Número de identificación del cliente a consultar, obligatorio", "CONSULTAR PROYECTOS DE UN CLIENTE");
                    JOptionPane.showMessageDialog(null, consultarProyectosDadoNumIDECliente(losProyectos, numeroIde));
                    break;

                case 10:
                    codigoProyecto = solicitarDatoObligatorio("Código del proyecto al que se registra el integrante, obligatorio", "REGISTRAR INTEGRANTE A UN PROYECTO");
                    JOptionPane.showMessageDialog(null, registrarIntegranteProyectoDadoCodigo(losProyectos, codigoProyecto));
                    break;

                case 11:
                    codigoProyecto = solicitarDatoObligatorio("Código del proyecto al que se registra el equipo, obligatorio", "REGISTRAR EQUIPO A UN PROYECTO");
                    JOptionPane.showMessageDialog(null, registrarEquipoProyectoDadoCodigo(losProyectos, codigoProyecto));
                    break;

                case 12:
                    codigoProyecto = solicitarDatoObligatorio("Código del proyecto del que se elimina el integrante, obligatorio", "ELIMINAR INTEGRANTE DE UN PROYECTO");
                    JOptionPane.showMessageDialog(null, eliminarIntegranteProyectoDadoCodigo(losProyectos, codigoProyecto));
                    break;

                case 13:
                    generarArchivoDeObjetosProyectos(losProyectos);
                    break;

                case 14:
                    generarArchivoDeObjetosClientes(losProyectos);
                    break;

                case 15:
                    proyectosLeidos = leerArchivoDeObjetosProyectos();
                    if(!proyectosLeidos.isEmpty()){
                        losProyectos = proyectosLeidos;
                        JOptionPane.showMessageDialog(null, consultarTodosProyectos(losProyectos));
                    }
                    break;

                case 16:
                    clientesLeidos = leerArchivoDeObjetosClientes();
                    if(!clientesLeidos.isEmpty()){
                        losClientes = clientesLeidos;
                        resultado = "Clientes leídos del archivo\n";
                        for(int i=0; i<losClientes.size(); i++){
                            resultado += losClientes.get(i).toString();
                            resultado += "\n";
                        }
                        JOptionPane.showMessageDialog(null, resultado);
                    }
                    break;

                case 17:
                    codigoProyecto = solicitarDatoObligatorio("Código del proyecto a consultar, obligatorio", "CONSULTAR PROYECTO DADO CÓDIGO");
                    JOptionPane.showMessageDialog(null, consultarProyectoDadoCodigo(losProyectos, codigoProyecto));
                    break;

                case 18:
                    do{
                        tipoCliente = JOptionPane.showInputDialog(null, "Tipo de cliente a consultar: Empresa o PersonaNatural",
                                                                "CONSULTAR PROYECTOS DADO TIPO DE CLIENTE", JOptionPane.QUESTION_MESSAGE).trim();
                        if(!tipoCliente.equalsIgnoreCase("Empresa") && !tipoCliente.equalsIgnoreCase("PersonaNatural")){
                            JOptionPane.showMessageDialog(null, "Entrada inválida: dato no cumple con restricción.\n",
                                                        "CONSULTAR PROYECTOS DADO TIPO DE CLIENTE", JOptionPane.ERROR_MESSAGE);
                        }
                    } while(!tipoCliente.equalsIgnoreCase("Empresa") && !tipoCliente.equalsIgnoreCase("PersonaNatural"));
                    JOptionPane.showMessageDialog(null, consultarProyectosDadoTipoCliente(losProyectos, tipoCliente));
                    break;

                case 19:
                    codigoProyecto = solicitarDatoObligatorio("Código del proyecto a actualizar, obligatorio", "ACTUALIZAR ESTADO DE UN PROYECTO");
                    JOptionPane.showMessageDialog(null, actualizarEstadoProyectoDadoCodigo(losProyectos, codigoProyecto));
                    break;

                case 0:
                    JOptionPane.showMessageDialog(null, "El programa se cerrará. Gracias por utilizar nuestros servicios.");
                    System.exit(0);
                    break;

                case -1:
                    //Entrada con formato incorrecto: el mensaje ya fue mostrado
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Digite un número entre 0 y 19.",
                                                "GESTIÓN DE PROYECTOS: menú", JOptionPane.ERROR_MESSAGE);
            }
        }while(opcion!=0);

    }//fin menú

    /**
     * Método: principal
     *         Ejecuta el método que gestiona el menú de operaciones.
     */
    public static void main(String[] args) {
        gestionarMenuOperaciones();

    }//fin main

}//fin class
